//  main.cpp
//  Project 5
//
//  Created by Shveta Shah on 4/15/17.
//  Copyright � 2017 Shveta Shah. All rights reserved.
//
//  Author: Shveta Shah
//  TA: Ellen  @ 1pm, Tue
//  System: VS
//  Program #5: Across Words
//
//	This program read four letter words from different size dictionary and print random words
//  in the board, scramble that board so user can solve the baord and after that match those
//  words with the selected dictionary. If a user want take their own words they can take it 
//  and make their own puzzel.
//  
//


#include<iostream>
#include<string.h>	   // Enables use of string function
#include<ctype.h>	  // Enables use of lower and upper letter
#include<stdlib.h>   // Enables use of rand()
#include<time.h>    // Enables use of time()
using namespace std;
const int MinWordLength = 4;             


void programmerInformation()
{
	printf("Author: Shveta Shah \n");
	printf("Program: #5, AcrossWords \n");
	printf("TA: Ellen Wang, Tue 1-1:50 \n");
	printf("April 15, 2017 \n\n");
	printf("\n");
	printf("\t Welcome to AcrossWord puzzle, where you rotate rows or columns\n");
	printf("\t to rotate the board back to containing four words. Each move is \n");
	printf("\t a row or column letter followed by the rotation distance 1,2 or 3.");
}


//========================================================
void readDictionary(char **&dictionary, int &numberOfWords, char *fileName)
{
	FILE *inFile;				//File pointer
	int i = 0;					//Index for a new dictionary array
	int wordlength = 4;			//length of a word 
	int wordIndex = 0;			//index of textfile
	char inputLine[81];

	inFile = fopen(fileName, "r");			//Read file
	if (inFile == NULL) {
		printf("Could not open file %s \n", fileName);
		exit(-1);
	}

	while (fscanf(inFile, "%s", inputLine) != EOF) {     //find all 4 letter words from a file 
		if (strlen(inputLine) == 4) {
			numberOfWords++;
		}
	}
	fclose(inFile);   //Close textfile

	dictionary = (char **)malloc(sizeof(char *) * numberOfWords);  //Allocate a dictionary size from a text file

	for (int i = 0; i < numberOfWords; i++) {
		dictionary[i] = (char *)malloc(sizeof(char) * (wordlength + 1));  //Allocate space for 4-letter words
	}

	inFile = fopen(fileName, "r"); //Reopen a textfile
	if (inFile == NULL) {
		printf("Could not open file %s \n", fileName);
		exit(-1);
	}

	while (fscanf(inFile, "%s", inputLine) != EOF) {    //Copy all 4 ltter textfile words into a dictionary
		if (strlen(inputLine) == wordlength) {
			strcpy(dictionary[wordIndex], inputLine);
			wordIndex++;
		}
	}
	printf("There are %d %d-letter words.\n", numberOfWords, wordlength);

	fclose(inFile);   //Close a textfile
}


void chooseOption(char fileName[81])
{
	int dictionarySize;

	//Inform user about functions 
	printf("When prompted to provide input you may enter: \n");
	printf("\t Enter 'r' to reset the board to user-defined values. \n");
	printf("\t Enter 'u' to unveil the underlying words/ \n");
	printf("\t Enter 's' to auto solve the board (Extra Credit) \n");
	printf("\t Enter 'x' to exit the program.\n\n");

	cout << "Which dictionary size do you want? (1 = small, 2 = medium, 3 = large):";
	cin >> dictionarySize;

	//option to select different textfile
	if (dictionarySize == 1) { 
		strcpy(fileName, "smallDictionary.txt");
	}			
	else if (dictionarySize == 2) { 
		strcpy(fileName, "mediumDictionary.txt");
	}
	else if (dictionarySize == 3) { 
		strcpy(fileName, "largeDictionary.txt"); 
	}
}


//=========================================================
void displayBoard(char board[16])
{
	char rowLetter = 'A';
	printf(" \n");
	printf("      E F G H \n");
	printf("    --------- \n");
	printf("  %c|  ", rowLetter);
		
	for (int i = 0; i<16; i++) {
		printf("%c ", board[i]);				// At the end of each line display the row letter, and print the new line
		if ((i + 1) % 4 == 0) {
			rowLetter++;
			printf("\n");                         // Now at the beginning of the new line, display the next row letter
			if (rowLetter < 'E') {
				printf("  %c|  ", rowLetter);   // display row letter at beginning of next line
			}
		}
	}
	printf(" \n");
}//end displayBoard()


char unScrambleBoard(char board[16], char **&dictionary, int numberOfWords, char unveiling[16]) 
//will orgranize the characters in displayboard
{
	int i;
	int row, column, newRow;

	srand((char)time(NULL));                            //chose random characters to put in displayboard
	for (row = 0; row < 4; row++) {
		newRow = rand() % numberOfWords;
		for (column = 0; column < 4; column++) {
			board[row * 4 + column] = dictionary[newRow][column];
			unveiling[row * 4 + column] = dictionary[newRow][column];      
		}
	}
	return 0;
}


int leftShift(int i, char *board) {          //shift a select row to the left by swapping
	int temp;                                // temperary variable for swapping
	temp = board[i];
	board[i] = board[i - 1];
	board[i - 1] = board[i - 2];
	board[i - 2] = board[i - 3];
	board[i - 3] = temp;

	return 0;
}


int downShift(int i, char *board) {         //shift a select column to down
	int temp;  
	temp = board[i];
	board[i] = board[i - 4];
	board[i - 4] = board[i - 8];
	board[i - 8] = board[i - 12];
	board[i - 12] = temp;
	return 0;
}


void rotationOne(char board[], char row, int direction) {                   // rotate selected column and row by 1 shift
	if ((row == 'A') && (direction == 1)) { leftShift(3, board); }
	else if ((row == 'B') && (direction == 1)) { leftShift(7, board); }
	else if ((row == 'C') && (direction == 1)) { leftShift(11, board); }
	else if ((row == 'D') && (direction == 1)) { leftShift(15, board); }
	else if ((row == 'E') && (direction == 1)) { downShift(12, board); }
	else if ((row == 'F') && (direction == 1)) { downShift(13, board); }
	else if ((row == 'G') && (direction == 1)) { downShift(14, board); }
	else if ((row == 'H') && (direction == 1)) { downShift(15, board); }
}


//Rotate a board 2 times                     
int leftShift2(int j, char *board) {                         //shift to left a selcted row two times
	int temp;
	temp = board[j];
	board[j] = board[j + 2];
	board[j + 2] = temp;

	temp = board[j + 1];
	board[j + 1] = board[j + 3];
	board[j + 3] = temp;
	return 0;
}


int downShift2(int j, char *board) {						//shift to down a selcted column twice
	int temp;
	temp = board[j];
	board[j] = board[j + 8];
	board[j + 8] = temp;
	temp = board[j + 4];
	board[j + 4] = board[j + 12];
	board[j + 12] = temp;
	return 0;
}


//====================================
//rotate selected column and row two times
void rotation2(char board[], char row, int direction) {
	if ((row == 'A') && (direction == 2)) { leftShift2(0, board); }
	else if ((row == 'B') && (direction == 2)) { leftShift2(4, board); }
	else if ((row == 'C') && (direction == 2)) { leftShift2(8, board); }
	else if ((row == 'D') && (direction == 2)) { leftShift2(12, board); }
	else if ((row == 'E') && (direction == 2)) { downShift2(0, board); }
	else if ((row == 'F') && (direction == 2)) { downShift2(1, board); }
	else if ((row == 'G') && (direction == 2)) { downShift2(2, board); }
	else if ((row == 'H') && (direction == 2)) { downShift2(3, board); }
}


//====================================rotate board 3 times
int leftShift3(int i, char *board) {                      //shift a selected row 3 times
	int temp;
	temp = board[i];
	board[i] = board[i + 1];
	board[i + 1] = board[i + 2];
	board[i + 2] = board[i + 3];
	board[i + 3] = temp;

	return 0;
}


//================================
int downShift3(int i, char *board) {                     // shift a selcted column 3 times
	int temp;
	temp = board[i];
	board[i] = board[i + 4];
	board[i + 4] = board[i + 8];
	board[i + 8] = board[i + 12];
	board[i + 12] = temp;
	return 0;
}


//================================
void rotation3(char board[], char row, int direction) {                       // rotate selected column/row 3 times
	if ((row == 'A') && (direction == 3)) { leftShift3(0, board); }
	else if ((row == 'B') && (direction == 3)) { leftShift3(4, board); }
	else if ((row == 'C') && (direction == 3)) { leftShift3(8, board); }
	else if ((row == 'D') && (direction == 3)) { leftShift3(12, board); }
	else if ((row == 'E') && (direction == 3)) { downShift3(0, board); }
	else if ((row == 'F') && (direction == 3)) { downShift3(1, board); }
	else if ((row == 'G') && (direction == 3)) { downShift3(2, board); }
	else if ((row == 'H') && (direction == 3)) { downShift3(3, board); }
}


//==================================Computer moves
void scrambleBoard(char board[16]) {						//random moves done by a computer
	char rowOption[4] = { 'A','B','C','D' };
	char columnOption[4] = { 'E', 'F', 'G', 'H' };
	int numberOption[3] = { 1, 2, 3 };

	int alphabetOptionIn, numberOptionIn, randomNumber;
	int i = 0;
	char randomAlphabet;

	while (i < 2) {                                       //coputer randomly takes two rows and 1 column
		int rowOptionIn = rand() % 4;
		int numberOptionIn = rand() % 3;
		char randomRow = rowOption[rowOptionIn];
		int randomNumber = numberOption[numberOptionIn];

		cout << "randomRow: "		<<randomRow			<< endl;
		cout << "randomNumber: "	<<randomNumber		<< endl;
		
		rotationOne(board, randomRow, randomNumber);
		rotation2(board, randomRow, randomNumber);
		rotation3(board, randomRow, randomNumber);

		i++;
		//displayBoard(board);
	}

	int columnOptionIn = rand() % 4;								
	numberOptionIn = rand() % 3;
	char randomColumn = columnOption[columnOptionIn];
	randomNumber = numberOption[numberOptionIn];

	cout << "randomColumn: " << randomColumn << endl;
	cout << "randomNumber: " << randomNumber << endl;
	rotationOne(board, randomColumn, randomNumber);
	rotation2(board, randomColumn, randomNumber);
	rotation3(board, randomColumn, randomNumber);
}


//===================================================  
void resetBoard(char board[16]) {
	char uEnter[17];             //uEnter a 16 array board with a NULL character
	
	cout << "Enter 16 char values to reset the board: ";  //user will enter 16 character of an array
	cin >> uEnter;
	cout << endl;

	if (strlen(uEnter) == 16) {                          // enter only 16 letters of an array
		strcpy(board, uEnter);
		displayBoard(board);
	}
	else if ((strlen(uEnter) < 16) || (strlen(uEnter) > 16)) {
		cout << "Sorry, needed to provide exactly"
			<< "16 characters of user input to reset the board."
			<< "Please retry." << endl;
		resetBoard(board);
	}	
}


//=========================
int winCondition(char board[16], char unveiling[16]) {           //find all the matching words in the dictionary
	char winArray[16];
	strcpy(winArray, board);
	for (int i = 0; i < 16; i++) {
		if (winArray[i] == unveiling[i]) {
			return 2;
		}
		else {
			return 1;
		}
	}
	return 0;
}



//======================================================================
int main()
{
	int numberOfWords = 0;             //number of 4 letter words in dictionary
	char fileName[81];				   //size of a file
	char board[16];						// board of 16 letter array
	char unveiling[16];					// gameBoard wihtout scramble
	char **dictionary;					
	char row;
	int direction;						// direction of a row/column
	int moveNumber = 1;					// Move number during each move
	
	//Choose option to open a file
	chooseOption(fileName);

	//Read selected dictionary
	readDictionary(dictionary, numberOfWords, fileName);
	
	//Original gameboard
	unScrambleBoard(board, dictionary, numberOfWords, unveiling);
	
	//displayBoard(board);
	scrambleBoard(board);									//Board after scramble original board
	//displayBoard(board);

	while (1) {
		displayBoard(board);							//display a gameboard
		
		// Enter row/column and number of rotation
		cout << moveNumber << ". Enter the row or column to be rotated, and a number 1..3: ";
		cin >> row;

		row = toupper(row);
		moveNumber++;
		/*int won = winCondition(board, unveiling);
		if (won == 2) {
			printf("\ncongratulation you have won the game.\n");
			exit(0);
		}*/
		if (row == 'X') {								 //X will exit user from the game
			cout << "Exit from the program." << endl;
			return 0;
		}
		else if (row == 'R') {							//make a new board with user entered characters
			cout << "reset the board" << endl;
			resetBoard(board);
		}
		else if (row == 'U') {							// Print the original board
			cout << "Unveil the board." << endl;
			displayBoard(unveiling);
		}
		else if (row == 'S') {
			cout << "auto reset the board" << endl;     //show the all step from scramble to the destination 		
		}
		else {
			scanf("%d", &direction);
			
			rotationOne(board, row, direction);			//Rotate a board by 1 rotation
			rotation2(board, row, direction);			//Rotate a board by 2 rotation 
			rotation3(board, row, direction);			//Rotate a board by 3 rotation
		}
		/*winCondition(board, unveiling);
		if (won == 2) {
			printf("\ncongratulation you have won the game.\n");
			exit(0);*/
		//}
	}
		return 0;
}