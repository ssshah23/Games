//pegJumpsshah257.c
//This program will play a peg jumping game.
//This version of the program is fully use of functions.
//
//Author: Shvetaben Shah
//Program: #2. PegJump
//TA: Ellen, Tuesday 1pm
//Date: Feb 8, 2017
//
//System: Windows 10, Visual Studio
/* Running the program should look like:
Author: Shvetaben Shah
Assignment: 2, PegJump
TA: Ellen, Tuesday 1pm
Feb 8, 2017

This program represents the peg jumping puzzle.

The board starts out with a single blank position, represented by
the 'O'.  To make a move, select the letter of the peg to be moved,
then the letter of the destination position. (e.g. the first move
might be: d a, meaning we move peg �d� into blank position �a�.)
A peg must be able to jump over an adjacent peg into a blank for a
move to be valid.  The jumped peg is then removed from the board.
The game is over when there are no valid moves left to be made, or
when there is a single peg left.

At any point enter 'x' to exit the program.
		At any point enter 'x' to exit the program.
-----------------------
  Board    Positions
    o          A              
   + +        B C            
  + + +      D E F         
 + + + +    G H I J      
+ + + + +  K L M N O  

1. Enter your move: D a


-----------------------
  Board    Positions
    +          A              
   o +        B C            
  o + +      D E F         
 + + + +    G H I J      
+ + + + +  K L M N O  

2. Enter your move: K D


-----------------------
  Board    Positions
    +          A              
   o +        B C            
  + + +      D E F         
 o + + +    G H I J      
o + + + +  K L M N O  


.
.
.
.so on until invalid conditions don't full fill.
*/
//This program describe how to make and use different functions with various parameters and different loops



#include<stdio.h> 
#include<stdlib.h> 
#include<ctype.h>

//Programmer's informations
void authorInformation() {
	printf(" Author: Shvetaben Shah \n");
	printf(" Assignment: 2, PegJump \n");
	printf(" TA: Ellen, Tue 1:00-1:50pm \n");
	printf(" Feb 8, 2017 \n");
	printf(" \n");
} //----------------------------------------------------------------------


  //Program instructions 
void projectInstruction() {
	printf(" This program represents the peg jumping puzzle. \n");
	printf("\n");
	printf(" The board starts out with a single blanck position, represented by the 'O'.");
	printf("To make a move, select the letter of the peg to be moved, then the letter of the destination position.");
	printf("(e.g. the first move might be: d a, meaning we move peg 'd' into blank position 'a'.)");
	printf("A peg must be able to jump over an adjacent peg into a blank for a move to be valid.");
	printf("The jumped peg is then removed from the board. The game is over when there are no valid moves left to be made, or when there is a single peg left. \n");
	printf("\n");
	printf(" At any point enter 'x' to exit the program.");
	printf("\n");
	printf("\n Welcome to PegJump \n");
} //--------------------------------------------------------------------


  //Display a gameboard
void displayBoard(char p1, char p2, char p3, char p4, char p5, char p6, char p7, char p8, char p9, char p10, char p11, char p12, char p13, char p14, char p15)
{
	printf("\n -----------------------\n");

	//Display the board
	printf("   Board       Positions \n");
	printf("     %c           A    \n", p1);
	printf("    %c %c         B C   \n", p2, p3);
	printf("   %c %c %c       D E F  \n", p4, p5, p6);
	printf("  %c %c %c %c     G H I J \n", p7, p8, p9, p10);
	printf(" %c %c %c %c %c   K L M N O\n", p11, p12, p13, p14, p15);
	printf("\n \n");
} //-------------------------------------------------------------------------


  //Read the position of the gameboard
char getPieceAt(char from, char p1, char p2, char p3, char p4, char p5, char p6, char p7,
	char p8, char p9, char p10, char p11, char p12, char p13, char p14, char p15) {

	switch (from) {
		case 'A':
			return p1;
			break;
		case 'B':
			return p2;
			break;
		case 'C':
			return p3;
			break;
		case 'D':
			return p4;
			break;
		case 'E':
			return p5;
			break;
		case 'F':
			return p6;
			break;
		case 'G':
			return p7;
			break;
		case 'H':
			return p8;
			break;
		case 'I':
			return p9;
			break;
		case 'J':
			return p10;
			break;
		case 'K':
			return p11;
			break;
		case 'L':
			return p12;
			break;
		case 'M':
			return p13;
			break;
		case 'N':
			return p14;
			break;
		case 'O':
			return p15;
			break;
		default:
			return ' ';
			break;
	}
} //---------------------------------------------------------------------------------


  //set plus piece on the destination
void setPlusAt(char to, char * p1, char * p2, char * p3, char * p4, char * p5, char * p6, char * p7, char * p8, char * p9, char * p10, char * p11, char * p12, char * p13, char * p14, char * p15) {
	switch (to) {
		case 'A':
			*p1 = '+';
			break;
		case 'B':
			*p2 = '+';
			break;
		case 'C':
			*p3 = '+';
			break;
		case 'D':
			*p4 = '+';
			break;
		case 'E':
			*p5 = '+';
			break;
		case 'F':
			*p6 = '+';
			break;
		case 'G':
			*p7 = '+';
			break;
		case 'H':
			*p8 = '+';
			break;
		case 'I':
			*p9 = '+';
			break;
		case 'J':
			*p10 = '+';
			break;
		case 'K':
			*p11 = '+';
			break;
		case 'L':
			*p12 = '+';
			break;
		case 'M':
			*p13 = '+';
			break;
		case 'N':
			*p14 = '+';
			break;
		case 'O':
			*p15 = '+';
			break;
		default:
			printf("***Invalid character to set. Exiting");
			break;
	}
} //----------------------------------------------------------------------


  //Set the piece on source position
void setZeroAt(char from, char * p1, char * p2, char * p3, char * p4, char * p5, char * p6, char * p7, char * p8, char * p9, char * p10, char * p11, char * p12, char * p13, char * p14, char * p15)
{
	switch (from) {
		case 'A':
			*p1 = 'o';
			break;
		case 'B':
			*p2 = 'o';
			break;
		case 'C':
			*p3 = 'o';
			break;
		case 'D':
			*p4 = 'o';
			break;
		case 'E':
			*p5 = 'o';
			break;
		case 'F':
			*p6 = 'o';
			break;
		case 'G':
			*p7 = 'o';
			break;
		case 'H':
			*p8 = 'o';
			break;
		case 'I':
			*p9 = 'o';
			break;
		case 'J':
			*p10 = 'o';
			break;
		case 'K':
			*p11 = 'o';
			break;
		case 'L':
			*p12 = 'o';
			break;
		case 'M':
			*p13 = 'o';
			break;
		case 'N':
			*p14 = 'o';
			break;
		case 'O':
			*p15 = 'o';
			break;
		default:
			printf("***Invalid character to set. Exiting");
			break;
	}
}//---------------------------------------------------------------


 //set jump piece to zero
void middlePiece(char pieceJump, char * p1, char * p2, char * p3, char * p4, char * p5, char * p6, char * p7, char * p8, char * p9, char * p10, char * p11, char * p12, char * p13, char * p14, char * p15) {
	switch (pieceJump) {
		case 'A':
			*p1 = 'o';
			break;
		case 'B':
			*p2 = 'o';
			break;
		case 'C':
			*p3 = 'o';
			break;
		case 'D':
			*p4 = 'o';
			break;
		case 'E':
			*p5 = 'o';
			break;
		case 'F':
			*p6 = 'o';
			break;
		case 'G':
			*p7 = 'o';
			break;
		case 'H':
			*p8 = 'o';
			break;
		case 'I':
			*p9 = 'o';
			break;
		case 'J':
			*p10 = 'o';
			break;
		case 'K':
			*p11 = 'o';
			break;
		case 'L':
			*p12 = 'o';
			break;
		case 'M':
			*p13 = 'o';
			break;
		case 'N':
			*p14 = 'o';
			break;
		case 'O':
			*p15 = 'o';
			break;
		default:
			break;
	}
}//----------------------------------------------------------------------------


 //Winner conditions 
void winnerCondition(char * p1, char * p2, char * p3, char * p4, char * p5, char * p6, char * p7, char * p8, char * p9, char * p10, char * p11, char * p12, char * p13, char * p14, char * p15)
{
	printf("\n# left  Rating    \n");
	printf("------  ----------\n");
	printf(" >4      Dufus    \n");
	printf("  4      Poor     \n");
	printf("  3      Mediocre \n");
	printf("  2      Good Job \n");
	printf("  1      Awesome Genius!\n");

	printf("\n");
}//-------------------------------------


int main() {
	// Declare and initialize the board pieces
	char p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15;
	char from, to;
	char pieceJump = ' ';
	int numPegs = 14;
	int numMove = 1;

	p1 = 'o';
	p2 = p3 = p4 = p5 = p6 = p7 = p8 = p9 = p10 = p11 = p12 = p13 = p14 = p15 = '+';

	authorInformation();
	projectInstruction();
	displayBoard(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15);
	printf("\n");

	while (numMove != 14) {
		// Ask user for move values
		printf("%d. Enter where you move from and to: ", numMove);
		scanf(" %c %c", &from, &to);

		// Convert lower case letter to upper case
		from = toupper(from);
		to = toupper(to);

		if (from == 'x' || from == 'X') {
			break;
		}
		// Not valid moves
		if ((from < 'A') || (from > 'O')) {
			printf("***Invalid source. Please retry****\n");
			continue;
		}
		if ((to < 'A') || (to > 'O')) {
			printf("***Invalid destination. Please retry ***\n");
			continue;
		}
		if (getPieceAt(from, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15) != '+') {
			printf("***Source must have a piece. Please retry ****\n");
			continue;
		}
		if (getPieceAt(to, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15) == '+') {
			printf("***Destination must be empty. Please retry...\n");
			continue;
		}
		int pieceJump = ((from + to) / 2);
		if (getPieceAt(pieceJump, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15) == 'o') {
			printf("Must jump a piece. Please retry....\n");
			continue;
		}

		setZeroAt(from, &p1, &p2, &p3, &p4, &p5, &p6, &p7, &p8, &p9, &p10, &p11, &p12, &p13, &p14, &p15);
		setPlusAt(to, &p1, &p2, &p3, &p4, &p5, &p6, &p7, &p8, &p9, &p10, &p11, &p12, &p13, &p14, &p15);
		middlePiece(pieceJump, &p1, &p2, &p3, &p4, &p5, &p6, &p7, &p8, &p9, &p10, &p11, &p12, &p13, &p14, &p15);

		numPegs--;
		numMove++;
		displayBoard(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15);
	} // End while loop

	winnerCondition(&p1, &p2, &p3, &p4, &p5, &p6, &p7, &p8, &p9, &p10, &p11, &p12, &p13, &p14, &p15);
	if (numMove == 13) {
		printf("You had 1 left. Awesome Genius! \n");
	}
	else if (numMove == 12) {
		printf("You had 2 left. Good Job \n");
	}
	else if (numMove == 11) {
		printf("You had 3 left. Mediocre \n");
	}
	else if (numMove == 10) {
		printf("You had 4 left. Poor \n");
	}
	else {
		printf("You had >4 left. Dufus \n");
	}

	printf("\nThanks for playing. Exiting....\n\n");
	printf("Done with program\n\n");
	return 0;

} //End main loop
