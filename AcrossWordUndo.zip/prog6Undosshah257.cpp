
//
//
//  main.cpp
//  Project 6
//  Created by Shveta Shah on 4/24/17.
//  Copyright © 2017 Shveta Shah. All rights reserved.
//
//  This program make a list of the moves and undo moves in Across word
//  print out arry in their choice of size
//
//
//  Author: Shveta Shah
//  TA: Ellen Wang @ 1pm, Tue
//  April 24, 2017
//  System: Windows 10
//  Program #6: Across Undo

//		I have used Professor Reed solution of Program 5, spring 2017 from starting.
//

#include <stdio.h>
#include <string.h>
#include <stdlib.h>  
#include <iostream>
#include <math.h>   
#include <time.h>  // to use rand()
using namespace std;

// Global constants
const char SMALL_DICTIONARY_NAME[] = "smallDictionary.txt";
const int WORD_LENGTH = 4;             // a word length for a puzzel
const int BOARD_SIZE = WORD_LENGTH * WORD_LENGTH;   // a board size of puzzel

//strcut define 
struct Node {
	char board[BOARD_SIZE + 1];
	int moveNumber;
	Node *pNext;
};


//--------------------------------------------------------------------------------
// Display Author name and program information
void displayIdentifyingInformation()
{
	printf("\n");
	printf("Author: Shveta Shah        \n");
	printf("Program: #6, AcrossWords   \n");
	printf("TA: Ellen Wang, Th 4-5     \n");
	printf("April 24, 2017             \n");
	printf("\n");
}//end displayIdentifyingInformation()


 //--------------------------------------------------------------------------------
 // Display Across word instructions
void displayInstructions()
{
	printf("Welcome to AcrossWord puzzle, where you rotate rows or columns       \n");
	printf("to restore the board back to containing four words. Each move is     \n");
	printf("a row or column letter followed by the rotation distance 1,2 or 3.   \n");
	printf("  \n");
	printf("When prompted to provide input you may enter:                        \n");
	printf("     Enter 'r' to reset the board to user-defined values.            \n");
	printf("     Enter 'u' to undo a move.                                       \n");
	printf("     Enter 'o' for original board to be shown                        \n");
	printf("     Enter 'x' to exit the program.                                  \n");
	printf("  \n");
}//end displayInstructions()


 //---------------------------------------------------------------------------
 // Read in dictionary.
 // allcate a memory as per small dictionary
void readInDictionary( char** &dictionary, int &numberOfWords)
{
	FILE *pInputFile;     // Pointer to input file
	char theWord[81];    
	int wordLength;       
	char dictionaryName[81];  // Will be set to the dictionary name corresponding to the dictionary size
	
	pInputFile = fopen(SMALL_DICTIONARY_NAME, "r");   // Returns null if not found.  Mode is "r" for read
											  
	if (pInputFile == NULL) {
		printf("File open failed.  Ensure file is in the right location.\n");
		printf("Exiting program...\n");
		exit(-1);
	}

	while (fscanf(pInputFile, "%s", theWord) != EOF) {
		wordLength = (int)strlen(theWord);
		if (wordLength == WORD_LENGTH) {
			numberOfWords++;
		}
	}
	fclose(pInputFile);

	// Allocate space for the dictionary of only four-letter words
	dictionary = (char **)malloc(sizeof(char *) * numberOfWords);
	
	for (int i = 0; i < numberOfWords; i++) {
		// Extra character for the NULL
		dictionary[i] = (char *)malloc(sizeof(char) * (WORD_LENGTH + 1));
	}

	// Now reread the input file, this time storing the four-letter words into dictionary
	pInputFile = fopen(SMALL_DICTIONARY_NAME, "r");   
	numberOfWords = 0;                               // reset, then use as index to count up
													 
	while (fscanf(pInputFile, "%s", theWord) != EOF) {
		wordLength = (int)strlen(theWord);
		if (wordLength == WORD_LENGTH) {
			strcpy(dictionary[numberOfWords++], theWord);
		}
	}
	fclose(pInputFile);

	printf("There are %d %d-letter words. \n", numberOfWords, WORD_LENGTH);
}//end readInDictionary()


 //--------------------------------------------------------------------------------
 // Place random words from dictionary into a board.
void placeFourRandomWordsOnBoard(char **dictionary, int numberOfWords, char board[BOARD_SIZE])           // Array of all dictionary words
	           // How many words there are in above dictionary
	   // The board where words will be placed
{
	srand((char)time(NULL));

	//Place word horizonatally
	for (int i = 0; i<WORD_LENGTH; i++) {
		int startingIndex = i * WORD_LENGTH;
		// Find random words from the dictionary
		int wordIndex = rand() % numberOfWords;

		// Copy the four word letters onto the board
		for (int j = 0; j<WORD_LENGTH; j++) {
			board[startingIndex + j] = dictionary[wordIndex][j];
		}
	}
	
}//end placeFourRandomWordsOnBoard()


//Display list of the moves
void displayList(Node *pHead, int moveNumber)
{
	cout << "   List: ";
	while (pHead != NULL) {
		cout << pHead->moveNumber;
		if (pHead->pNext != NULL)  cout << "->";
		pHead = pHead->pNext;
	}
	cout << endl;
}


//--------------------------------------------------------------------------------
// Display the board, taking the 16 board characters and displaying them
void displayBoard(char board[], Node *pHead, int &moveNumber)
{
	printf("\n");

	printf("     E F G H\n");
	printf("     -------\n");
	for (int row = 0; row<WORD_LENGTH; row++) {
		printf("  %c| ", 'A' + row);
		for (int col = 0; col<WORD_LENGTH; col++) {
			int index = row * WORD_LENGTH + col;
			printf("%c ", board[index]);
		}
		printf("\n");
	}
	fflush(stdout);  // flush the output buffer
}//end displayBoard()


 //--------------------------------------------------------------------------------------
 // Rotate the characters right "distance" number of times.  Changes to the characters
void rotate(char &c1, char &c2, char &c3, char &c4, int distance)
{
	char c;
	// Do a single rotation the determined number of times
	for (int i = 0; i<distance; i++) {
		c = c1;   // store the first character so it is not overwritten and available at the end
		c1 = c4; c4 = c3; c3 = c2; c2 = c;
	}
}


//--------------------------------------------------------------------------------------
// Board index positions for the rotations are:
void getCharactersAndMakeRotation(char board[BOARD_SIZE], char rowOrColumnToRotate, int rotateDistance)
{
	// Pull out the four board characters to be used in the rotation, and send them to actually do the rotation
	switch (toupper(rowOrColumnToRotate)) {
	case 'A': rotate(board[0], board[1], board[2], board[3], rotateDistance); break;
	case 'B': rotate(board[4], board[5], board[6], board[7], rotateDistance); break;
	case 'C': rotate(board[8], board[9], board[10], board[11], rotateDistance); break;
	case 'D': rotate(board[12], board[13], board[14], board[15], rotateDistance); break;
	case 'E': rotate(board[0], board[4], board[8], board[12], rotateDistance); break;
	case 'F': rotate(board[1], board[5], board[9], board[13], rotateDistance); break;
	case 'G': rotate(board[2], board[6], board[10], board[14], rotateDistance); break;
	case 'H': rotate(board[3], board[7], board[11], board[15], rotateDistance); break;
	default: 
		printf("Invalid row/col value of %c.  Exiting program...\n", rowOrColumnToRotate);
		exit(-1);
	}
}//end getCharactersAndMakeRotation()


 //--------------------------------------------------------------------------------------
 // Make two row rotations and one column rotation, randomly choosing in which of the
void makeBoardRotations(char board[BOARD_SIZE])
{
	srand(0);   // Seed the random number generator with time(0) rather than just 0,
	
	char rowsToUse[2];
	rowsToUse[0] = rand() % 4 + 'A';

	do {
		rowsToUse[1] = rand() % 4 + 'A';   // Add 0..3 to 'A', giving 'A'..'D'
	} while (rowsToUse[1] == rowsToUse[0]);

	// being placed at random into one of the three positions
	char rowOrColumnToUse[3] = { ' ',' ',' ' };
	rowOrColumnToUse[rand() % 3] = rand() % 4 + 'E';   
	
	int rowIndex = 0;
	for (int i = 0; i<3; i++) {
		if (rowOrColumnToUse[i] == ' ') {
			rowOrColumnToUse[i] = rowsToUse[rowIndex++];
		}
	}

	// Now make the three rotations
	for (int i = 0; i<3; i++) {
		int rotateDistance = (rand() % 3 + 1);  // We will rotate 1..3 times
		getCharactersAndMakeRotation(board, rowOrColumnToUse[i], rotateDistance);
	}
} // end makeBoardRotations()


  //--------------------------------------------------------------------------------------
  // Winning condition by binary search
int binarySearch(const char searchWord[WORD_LENGTH + 1],
	char *dictionary[],                  
	int numberOfWords)                    
{
	int low, mid, high;
	int searchResult = -1;  // Stores index of word if search succeeded, else -1

	low = 0;
	high = numberOfWords - 1;
	while (low <= high) {
		mid = (low + high) / 2;
		
		searchResult = strcmp(searchWord, dictionary[mid]);
		if (searchResult == 0) {
			// Word is in dictionary, so return the index where the word was found
			return mid;
		}
		else if (searchResult < 0) {
			high = mid - 1; // word should be located prior to mid location
		}
		else {
			low = mid + 1; // word should be located after mid location
		}
	}

	// Word was not found
	return -1;
}//end binarySearch()


 //--------------------------------------------------------------------------------------
 // Check four letter words are in the dictionar or not
bool done(char board[BOARD_SIZE], char **dictionary, int numberOfWords)
{
	bool allWordsAreFound = true;
	for (int i = 0; i<WORD_LENGTH; i++) {
		// Make a word out of the 4 letters
		char theWord[5];
		theWord[0] = board[i*WORD_LENGTH + 0];
		theWord[1] = board[i*WORD_LENGTH + 1];
		theWord[2] = board[i*WORD_LENGTH + 2];
		theWord[3] = board[i*WORD_LENGTH + 3];
		theWord[4] = '\0';    

		if (binarySearch(theWord, dictionary, numberOfWords) == -1) {
			// word was not found.
			allWordsAreFound = false;    
			break;
		}
	}

	return allWordsAreFound;
}// end done()


 //--------------------------------------------------------------------------------------
 // Reset the board with userEnter 16 characters
void resetBoard(char board[BOARD_SIZE])
{
	char userInput[81];
	userInput[0] = '\0';  
	while (strlen(userInput) != BOARD_SIZE) {
		printf("Enter %d char values to reset the board: ", BOARD_SIZE);
		scanf("%s", userInput);

		// Check userInput wordlength should be 16
		if (strlen(userInput) != 16) {
			printf("Sorry, needed to provide exactly 16 characters of user input to reset the board.  Please retry.\n");
		}    
	}
	 // User input length is correct. Copy over from user input into the board.
	for (int i = 0; i<BOARD_SIZE; i++) {
		board[i] = userInput[i];
	}
}//end resetBoard()


//Delete node from the list and restore previous move
void deleteNodeFromList(Node *&pHead, char board[], int &moveNumber)
{
	if (pHead->pNext == NULL) {
		cout << "*** You cannot undo past the beginning of the game.  Please retry."
			<< "\n";
		return;
	}
	moveNumber--;

	cout << "* Undoing move * \n";
	// Make sure old head of the list will be deleted
	Node *pTemp = pHead;
	pHead = pHead->pNext;

	// Delete the old head of the list
	delete pTemp;

	// Restore game values from the new list head
	strcpy(board, pHead->board);
	moveNumber = pHead->moveNumber;
}//end deleteNodeFromList()


//Add a new node to the list as per move
void addNodeToList(Node *&pHead, char board[], int &moveNumber)
{
	// Create a new node and store current values into it
	Node *pTemp = new Node;
	strcpy(pTemp->board, board);
	pTemp->moveNumber = moveNumber;
	pTemp->pNext = pHead;

	// Prepend it onto the front of the list
	pHead = pTemp;
}


//--------------------------------------------------------------------------------------
// main function
int main() {
	// Declare the board
	char board[BOARD_SIZE];	   
	char backupBoard[BOARD_SIZE]; // for unveil a board
	char **dictionary;     		 //will store allocated dictionary
	int numberOfWords = 0; 	 	 // count 4-letter words in the dictionary
	int moveNumber = 1;    	 	 //display move numbers as you play
	char rowOrColumn = ' ';  	 
	char rotateDistance = ' ';   
								 
	displayIdentifyingInformation();
	displayInstructions();

	Node *pHead = NULL;
	// Seed the random number generator
	srand(0);
	// Read 4-letter words from the dictionary
	readInDictionary(dictionary, numberOfWords);

	// Choose four random words to print a different board eachtime
	placeFourRandomWordsOnBoard(dictionary, numberOfWords, board);

	// Two row rotation and one column
	makeBoardRotations(board);

	addNodeToList(pHead, board, moveNumber);

	// Make a copy of the original board
	for (int i = 0; i<BOARD_SIZE; i++) {
		backupBoard[i] = board[i];
	}
	
	displayBoard(board, pHead, moveNumber);
	displayList(pHead, moveNumber);
	//Ask user to enter row or column rotation
	while (!done(board, dictionary, numberOfWords)) {
		printf("%d. Enter the row or column to be rotated, and a number 1..3: ", moveNumber);
		scanf(" %c", &rowOrColumn);
		
		// Check for 'r' to reset, 'u' to cheat, 's' to solve', or 'x' to exit
		if (rowOrColumn == 'x') {
			printf("You chose x to Exit...\n");
			break;
		}
		else if (rowOrColumn == 'r') {
			printf("You chose 'r' to reset the board. \n");
			resetBoard(board);
			displayBoard(board, pHead, moveNumber);
			continue;	// continue back up to retry user input
		}
		else if (rowOrColumn == 'o') {
			// 'u' to "unveil" was chosen. Display the with answer and modified board
			printf("You chose 'o' for the original board to be shown.  Here are the underlying words: \n");
			displayBoard(backupBoard, pHead, moveNumber);
			printf("\n");
			displayBoard(board, pHead, moveNumber);
			continue;
		}
		else if (rowOrColumn == 'u') {
			//undo the board
			printf("You chose 'u' to undo the most recent move. \n");
			deleteNodeFromList(pHead, board, moveNumber);
			displayBoard(board, pHead, moveNumber);
			displayList(pHead, moveNumber);
			continue;			
		}
		
		moveNumber++;
		scanf(" %c", &rotateDistance);
		
		// Make the rotation
		getCharactersAndMakeRotation(board, toupper(rowOrColumn), rotateDistance - '0');
		
		addNodeToList(pHead, board, moveNumber);
		// Display the board
		displayBoard(board, pHead, moveNumber);
		displayList(pHead, moveNumber);

	}

	// Display congratulatory message if solution was founds
	if (done(board, dictionary, numberOfWords)) {
		printf("You did it!  Well done. \n");
	}

	printf("\nEnd of program.  Exiting... \n");
	return 0;
}// end main()
